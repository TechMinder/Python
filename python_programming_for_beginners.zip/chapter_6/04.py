#!/usr/bin/env python3

contacts = {'Jason': '555-0123', 'Carl': '555-0987'}
del contacts['Jason']
print(contacts)
