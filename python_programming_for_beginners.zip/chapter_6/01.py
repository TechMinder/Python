#!/usr/bin/env python3

contacts = {'Jason': '555-0123', 'Carl': '555-0987'}
jasons_phone = contacts['Jason']
carls_phone = contacts['Carl']

print('Dial {} to call Jason.'.format(jasons_phone))
print('Dial {} to call Carl.'.format(carls_phone))
