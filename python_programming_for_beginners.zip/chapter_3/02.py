#!/usr/bin/env python3

is_one_equal_to_two = 1 == 2
print(is_one_equal_to_two)
