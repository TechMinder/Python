#!/usr/bin/env python3

if 37 < 40:
    print('Thirty-seven is less than forty.')
