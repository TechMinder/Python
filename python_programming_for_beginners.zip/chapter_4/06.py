#!/usr/bin/env python3


def say_hi(name = 'there'):
    print('Hi {}!'.format(name))

say_hi()
say_hi('Jason')
