#!/usr/bin/env python3


def say_hi(first, last='Doe'):
    print('Hi {} {}!'.format(first, last))

say_hi('Jane')
say_hi('John', 'Coltrane')
