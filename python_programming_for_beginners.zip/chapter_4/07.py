#!/usr/bin/env python3


def say_hi(first, last):
    print('Hi {} {}!'.format(first, last))

say_hi('Jane', 'Doe')
