#!/usr/bin/env python3


def say_hi():
    print('Hi!')

say_hi()
