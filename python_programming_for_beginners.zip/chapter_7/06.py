#!/usr/bin/env python3

contact_info = ['555-0123', 'jason@example.com']
(phone, email) = contact_info
print(phone)
print(email)
