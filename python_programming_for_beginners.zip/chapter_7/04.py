#!/usr/bin/env python3

days_of_the_week = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
for day in days_of_the_week:
    print(day)
