#!/usr/bin/env python3

animals = ['man', 'bear', 'pig', 'cow', 'duck', 'horse', 'dog']
for number in range(0, len(animals), 2):
    print(animals[number])
