#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
for animal in animals:
    print(animal.upper())
