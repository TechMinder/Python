#!/usr/bin/env python3

part_of_a_horse = 'horse'[1:3]
print(part_of_a_horse)
