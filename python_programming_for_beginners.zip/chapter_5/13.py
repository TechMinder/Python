#!/usr/bin/env python3

animals = ['man', 'bear', 'pig', 'cow', 'duck', 'horse', 'dog']

index = 0

while index < len(animals):
    print(animals[index])
    index += 1
