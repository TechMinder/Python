#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
animals.insert(0, 'horse')
print(animals)

animals.insert(2, 'duck')
print(animals)
