#!/usr/bin/env python3

animals = ['man', 'bear', 'pig']
print(len(animals))
animals.append('cow')
print(len(animals))
