#!/usr/bin/env python3
fruit = 'apple'
fruit_len = len(fruit)
print(fruit_len)
