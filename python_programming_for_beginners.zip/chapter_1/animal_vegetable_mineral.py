#!/usr/bin/env python3
animal = 'cat'
vegetable = 'broccoli'
mineral = 'gold'

print('Here is an animal, a vegetable, and a mineral.')
print(animal)
print(vegetable)
print(mineral)
