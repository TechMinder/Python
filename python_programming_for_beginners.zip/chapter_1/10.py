#!/usr/bin/env python3
fruit = 'apple'
first_char = fruit[0]
