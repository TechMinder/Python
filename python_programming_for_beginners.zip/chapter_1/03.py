#!/usr/bin/env python3
first3letters = 'ABC'
first_three_letters = 'ABC'
firstThreeLetters = 'ABC'
