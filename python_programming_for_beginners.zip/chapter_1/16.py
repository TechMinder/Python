#!/usr/bin/env python3
fruit = 'Apple'
print(fruit.upper())
