#!/usr/bin/env python3
print('I ' + 'love ' + 'Python.')
print('I' + ' love' + ' Python.')
