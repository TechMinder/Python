#!/usr/bin/env python3

import say_hi2
say_hi2.say_hi()
