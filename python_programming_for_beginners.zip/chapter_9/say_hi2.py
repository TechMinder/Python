#!/usr/bin/env python3


def say_hi():
    print('Hi!')

print('Hello from say_hi2.py!')
