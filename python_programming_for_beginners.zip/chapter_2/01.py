#!/usr/bin/env python3

integer = 42
float = 4.2
